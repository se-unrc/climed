package climed;
import java.io.*;

public class Main {    
    public static void main(String args[]) throws IOException {
    	@SuppressWarnings("unused")        
        MediadorPrincipal nuevo = new MediadorPrincipal();
    }	
}